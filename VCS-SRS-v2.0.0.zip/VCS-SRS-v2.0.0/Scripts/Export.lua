
pcall(function() local dcsSr=require('lfs');dofile(dcsSr.writedir()..[[Mods\Services\DCS-SRS\scripts\DCS-SimpleRadioStandalone.lua]]); end,nil) 