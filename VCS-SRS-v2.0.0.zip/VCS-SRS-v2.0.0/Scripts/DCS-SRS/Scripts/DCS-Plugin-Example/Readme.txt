Assuming the Mod is named "MyModName", copy the SRS folder into:

Saved Games\DCS\Mods\Aircraft\MyModName\

and modify autoload.lua according to the needing.
